Partisan Project: weapon handling sounds package

shipped-in-site/    the 42 takes the site plays (also in assets/audio/foley on main)
unshipped-cuts/     all other extracted cuts by class (click, clunk, handle, hit, long, ratchet, slide, ui-suspect), plus the per-class review reels and their indexes
reference/          cue-sheet-analysis.csv (the analysis reference sheet for every cut), tlou2-workbench-reference.webp (the TLOU2 weapon bench reference image the earlier workbench used), bench-audio-cues.js (the earlier cue mapping), sfx-readme-original.txt

Note: the TLOU2 item is a still image reference. No gameplay video recording exists in either repository.
